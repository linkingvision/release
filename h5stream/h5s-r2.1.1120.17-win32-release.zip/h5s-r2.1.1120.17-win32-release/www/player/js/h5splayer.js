/** 
 *=================WebSocket based Player
 *
 */
 
/** 
 * Interface with h5s websocket player API
 * @constructor
 * @param {string} videoId - id of the video element tag
*/

function H5sPlayerWS(videoId)
{
	
	this.sourceBuffer;
	this.buffer = [];	
	this.mediaSource;
	this.video;
	this.wsSocket;
	this.checkSourceBufferId;
	this.keepaliveTimerId;
	this.emptyBuffCnt = 0;
	this.lastBuffTime = 0;
	this.buffTimeSameCnt = 0;
	this.bNeedReconnect = false;
	
	this._videoId = videoId;
	
	setInterval(this.ReconnectFunction.bind(this), 3000);
	
}

H5sPlayerWS.prototype.ReconnectFunction = function() 
{
	console.log('Try Reconnect...', this.bNeedReconnect);
	if (this.bNeedReconnect === true)
	{
		console.log('Reconnect...');
		this.setupSourceBuffer(this.videoId);
		this.setupWebSocket();
		this.bNeedReconnect = false;
	}
	console.log('Try Reconnect...', this.bNeedReconnect);
}
	
	
H5sPlayerWS.prototype.H5SWebSocketClient = function(h5spath) 
{
	var socket;
	console.log("H5SWebSocketClient");
	try {
		//alert(window.location.protocol);
		if (window.location.protocol == "http:") 
		{
			if (typeof MozWebSocket != "undefined")
			{
				socket = new MozWebSocket('ws://' + window.location.host + h5spath);
			}else
			{
				socket = new WebSocket('ws://' + window.location.host + h5spath);
			}
		}
		if (window.location.protocol == "https:")
		{	
			//alert(window.location.host);
			console.log(window.location.host);
			if (typeof MozWebSocket != "undefined")
			{
				socket = new MozWebSocket('wss://' + window.location.host + h5spath);
			}else
			{
				socket = new MozWebSocket('wss://' + window.location.host + h5spath);
			}				
		}
		console.log(window.location.host);
	} catch (e) {
		alert('error');
		return;
	}
	return socket;
}
	
	
H5sPlayerWS.prototype.readFromBuffer = function()
{
	if (this.buffer.length === 0 || this.sourceBuffer.updating) 
	{
	  return;
	}
	try {
	  var data = this.buffer.shift();
	  var dataArray = new Uint8Array(data);
	  this.sourceBuffer.appendBuffer(dataArray);
	} catch (e) {
	  console.log(e);
	}
}
H5sPlayerWS.prototype.keepaliveTimer = function()	
{
	this.wsSocket.send("keepalive");
}

H5sPlayerWS.prototype.onWebSocketData = function(msg)	
{
/*
	var blob = msg.data;

	var fileReader = new FileReader();
	fileReader.onload = function () {
		this.buffer.push(this.result);
		readFromBuffer();
	};

	fileReader.readAsArrayBuffer(blob);
	*/
	this.buffer.push(msg.data);
	this.readFromBuffer();
} 
	

H5sPlayerWS.prototype.setupSourceBuffer = function()	
{
	window.MediaSource = window.MediaSource || window.WebKitMediaSource;
	if (!window.MediaSource) {
	  console.log('MediaSource API is not available');
	}

	this.mediaSource = new window.MediaSource();

	this.video = document.getElementById(this._videoId);
	this.video.autoplay = true;
	console.log(this._videoId);

	//var h5spath = video.getAttribute('h5spath');
	var h5spath = "/h5swsapi";
	

	/* var video = document.querySelector('h5sVideo'); */
	//alert(h5spath);
	this.video.src = window.URL.createObjectURL(this.mediaSource);
	this.video.play();

	this.mediaSource.addEventListener('sourceopen', this.mediaSourceOpen.bind(this), false);
		
}

H5sPlayerWS.prototype.mediaSourceOpen = function()	
{
	console.log("Add SourceBuffer");
	//var strCodec = 'video/mp4; codecs="avc1.420028"';
	//var strCodec = 'video/mp4; codecs="avc1.42E01E"';
	var strCodec = 'video/mp4; codecs="avc1.640029"';
	this.sourceBuffer = this.mediaSource.addSourceBuffer(strCodec);
	this.mediaSource.duration = Infinity;
	this.mediaSource.removeEventListener('sourceopen', this.mediaSourceOpen, false);
	this.sourceBuffer.addEventListener('updateend', this.readFromBuffer.bind(this), false);		
}
	
H5sPlayerWS.prototype.setupWebSocket = function(token)	
{
	this.video = document.getElementById(this._videoId);
	this.video.autoplay = true;
	
	//var h5spath = this.video.getAttribute('h5spath');
	var h5spath = "/h5swsapi";
	//var token = this.video.getAttribute('token');
	h5spath = h5spath + "?token=" + token;
	console.log(h5spath);
	
	this.wsSocket = this.H5SWebSocketClient(h5spath);
	this.wsSocket.binaryType = 'arraybuffer';
	this.wsSocket.onmessage = this.onWebSocketData.bind(this);
	this.wsSocket.onopen = function()
	{
		this.checkSourceBufferId = setInterval(this.CheckSourceBuffer.bind(this), 3000);
		this.keepaliveTimerId = setInterval(this.keepaliveTimer.bind(this), 1000);
	}
	
	this.wsSocket.onclose = function () {
		this.CleanupWebSocket();
		this.CleanupSourceBuffer();
		this.bNeedReconnect = true;
	}
}
	
H5sPlayerWS.prototype.CleanupSourceBuffer = function()
{
	console.log('Cleanup Source Buffer');
	this.sourceBuffer.removeEventListener('updateend', this.readFromBuffer, false);
	this.sourceBuffer.abort();

	if (document.documentMode || /Edge/.test(navigator.userAgent)) 
	{
		console.log('IE or EDGE!');
	}else
	{
		this.mediaSource.removeSourceBuffer(this.sourceBuffer);
	}
	//Clear the this.video source
	this.video.src = '';
	this.sourceBuffer = null;
	this.mediaSource = null;
	this.buffer = [];
	
}

H5sPlayerWS.prototype.CleanupWebSocket = function()
{
	clearInterval(this.keepaliveTimerId);
	clearInterval(this.checkSourceBufferId);
	this.emptyBuffCnt = 0;
	this.lastBuffTime = 0;
	this.buffTimeSameCnt = 0;
}
	

H5sPlayerWS.prototype.CheckSourceBuffer = function()	
{
	console.log("CheckSourceBuffer");
	if (this.sourceBuffer.buffered.length <= 0)
	{
		this.emptyBuffCnt ++;
		if (this.emptyBuffCnt > 8)
		{
			console.log("CheckSourceBuffer Close 1");
			this.wsSocket.close();
			return;
		}
	}else
	{
		this.emptyBuffCnt = 0;
		var buffStartTime = this.sourceBuffer.buffered.start(0);
		var buffEndTime = this.sourceBuffer.buffered.end(0);
		
		var buffDiff = buffEndTime - this.video.currentTime;
		if (buffDiff > 5 || buffDiff < 0)
		{
			console.log("CheckSourceBuffer Close 2");
			this.wsSocket.close();
			return;				
		}
		
		if ( buffEndTime == this.lastBuffTime)
		{
			this.buffTimeSameCnt ++;
			if (this.buffTimeSameCnt > 3)
			{
				console.log("CheckSourceBuffer Close 3");
				this.wsSocket.close();
				return;
			}
		}else
		{
			this.buffTimeSameCnt = 0;
		}
		
		this.lastBuffTime = buffEndTime;
		
	}

}

/** 
 * Connect a websocket Stream to videoElement 
 * @param {string} id - id of WebRTC stream
*/
H5sPlayerWS.prototype.connect = function(id) {
	
	this.setupSourceBuffer();
	
	/* start connect to server */
	this.setupWebSocket(id);
}


/** 
 * Disconnect a websocket Stream and clear videoElement source
*/
H5sPlayerWS.prototype.disconnect = function() {
	this.CleanupWebSocket();
	this.CleanupSourceBuffer();
	this.bNeedReconnect = false;
}



/**
 *=================HLS based Player
 *
 */
/** 
 * Interface with h5s websocket player API
 * @constructor
 * @param {string} videoId - id of the video element tag
*/
function H5sPlayerHls(videoId)
{
	var _videoId = videoId;
	var _reConnectInterval;

	video = document.getElementById(videoId);
	//video.autoplay = true;
	video.type="application/x-mpegURL";
	//webView.mediaPlaybackRequiresUserAction = NO;
	
	//var token = video.getAttribute('token');
	
	var lastTime = 0;
	var sameCnt = 0;
	function CheckPlaying() 
	{
		console.log("HLS video.ended", video.ended);
		console.log("HLS video.currentTime", video.currentTime);
		var currentTime = video.currentTime;
		if (lastTime != 0)
		{
			var diff = currentTime - lastTime;
			console.log("HLS diff", diff);
			if (diff === 0)
			{
				sameCnt ++;
			}
		}
		lastTime = currentTime;
		if (sameCnt > 3)
		{
			console.log("HLS reconnect");
			video.src = '';
			lastTime = 0;
			sameCnt = 0;
			video.src = 'http://' + window.location.host + '/hls/v1/' + token + '/hls.m3u8';
			video.play();
			
		}
		
	}
	
	//video.play();
		
}

/** 
 * Connect a websocket Stream to videoElement 
 * @param {string} id - id of WebRTC stream
*/
H5sPlayerHls.prototype.connect = function(id) {
	video = document.getElementById(_videoId);
	video.src = 'http://' + window.location.host + '/hls/v1/' + id + '/hls.m3u8';
	
	video.onended = function(e) {
		console.log('The End');
	};
	video.onpause = function(e) {
		console.log('Pause');
	};
	
	video.onplaying = function(e) {
		console.log('Playing');
	};
	video.onseeking = function(e) {
		console.log('seeking');
	};
	video.onvolumechange = function(e) {
		console.log('volumechange');
	};
	_reConnectInterval = setInterval(CheckPlaying, 3000);
}


/** 
 * Disconnect a websocket Stream and clear videoElement source
*/
H5sPlayerHls.prototype.disconnect = function() {
	clearInterval(_reConnectInterval);
	video.src = '';
	lastTime = 0;
	sameCnt = 0;
}

 
/** 
 * Check on iOS platform
*/
function H5siOS() {

  var iDevices = [
    'iPad Simulator',
    'iPhone Simulator',
    'iPod Simulator',
    'iPad',
    'iPhone',
    'iPod'
  ];

  if (!!navigator.platform) {
    while (iDevices.length) {
      if (navigator.platform === iDevices.pop()){ return true; }
    }
  }

  return false;
}
 
 
/** 
 *=================WebRTC based Player
 *
 */