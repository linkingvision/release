window.onload = function() {
	if (iOS())
	{
		HLSPlayVideo("h5sVideo1");
		//HLSPlayVideo("h5sVideo2");
		console.log('Play for iOS');
	}else
	{
		HLSPlayVideo("h5sVideo1");
		//H5SPlayVideo("h5sVideo1");
		//H5SPlayVideo("h5sVideo2");
	}
}

function H5SWebSocketClient(h5spath)
{
	var socket;
	console.log("H5SWebSocketClient");
	try {
		//alert(window.location.protocol);
		if (window.location.protocol == "http:") 
		{
			if (typeof MozWebSocket != "undefined")
			{
				socket = new MozWebSocket('ws://' + window.location.host + h5spath);
			}else
			{
				socket = new WebSocket('ws://' + window.location.host + h5spath);
			}
		}
		if (window.location.protocol == "https:")
		{	
			//alert(window.location.host);
			console.log(window.location.host);
			if (typeof MozWebSocket != "undefined")
			{
				socket = new MozWebSocket('wss://' + window.location.host + h5spath);
			}else
			{
				socket = new MozWebSocket('wss://' + window.location.host + h5spath);
			}				
		}
		console.log(window.location.host);
	} catch (e) {
		alert('error');
		return;
	}
	return socket;
}

function iOS() {

  var iDevices = [
    'iPad Simulator',
    'iPhone Simulator',
    'iPod Simulator',
    'iPad',
    'iPhone',
    'iPod'
  ];

  if (!!navigator.platform) {
    while (iDevices.length) {
      if (navigator.platform === iDevices.pop()){ return true; }
    }
  }

  return false;
}

function HLSPlayVideo(videoId)
{
		video = document.getElementById(videoId);
		//video.autoplay = true;
		video.type="application/x-mpegURL";
		//webView.mediaPlaybackRequiresUserAction = NO;
		
		var token = video.getAttribute('token');
		

		video.src = 'http://' + window.location.host + '/hls/v1/' + token + '/hls.m3u8';
		
		video.onended = function(e) {
			console.log('The End');
		};
		video.onpause = function(e) {
			console.log('Pause');
		};
		
		video.onplaying = function(e) {
			console.log('Playing');
		};
		video.onseeking = function(e) {
			console.log('seeking');
		};
		video.onvolumechange = function(e) {
			console.log('volumechange');
		};
		
		var lastTime = 0;
		var sameCnt = 0;
		function CheckPlaying() 
		{
			console.log("HLS video.ended", video.ended);
			console.log("HLS video.currentTime", video.currentTime);
			var currentTime = video.currentTime;
			if (lastTime != 0)
			{
				var diff = currentTime - lastTime;
				console.log("HLS diff", diff);
				if (diff === 0)
				{
					sameCnt ++;
				}
			}
			lastTime = currentTime;
			if (sameCnt > 3)
			{
				console.log("HLS reconnect");
				video.src = '';
				lastTime = 0;
				sameCnt = 0;
				video.src = 'http://' + window.location.host + '/hls/v1/' + token + '/hls.m3u8';
				video.play();
				
			}
			
		}
		setInterval(CheckPlaying, 3000);
		//video.play();
		
}

function H5SPlayVideo(videoId)
{
	var sourceBuffer;
	var buffer = [];	
	var mediaSource;
	var video;
	var wsSocket;
	var checkSourceBufferId;
	var keepaliveTimerId;
	var emptyBuffCnt = 0;
	var lastBuffTime = 0;
	var buffTimeSameCnt = 0;
	var bNeedReconnect = false;
	
	$(window).blur(function(){
	  console.log('blur');
	});
	$(window).focus(function(){
	  console.log('focus');
	});
	
	function ReconnectFunction() 
	{
		console.log('Try Reconnect...', bNeedReconnect);
		if (bNeedReconnect === true)
		{
			console.log('Reconnect...');
			setupSourceBuffer(videoId);
			setupWebSocket();
			bNeedReconnect = false;
		}
	}
	
	setInterval(ReconnectFunction, 3000);
	
	var readFromBuffer = function () 
	{
		if (buffer.length === 0 || sourceBuffer.updating) 
		{
		  return;
		}
		try {
		  var data = buffer.shift();
		  var dataArray = new Uint8Array(data);
		  sourceBuffer.appendBuffer(dataArray);
		} catch (e) {
		  console.log(e);
		}
	};
	
	function keepaliveTimer() 
	{
		wsSocket.send("keepalive");
	}

	function onWebSocketData(msg) 
	{
	/*
		var blob = msg.data;

		var fileReader = new FileReader();
		fileReader.onload = function () {
			buffer.push(this.result);
			readFromBuffer();
		};

		fileReader.readAsArrayBuffer(blob);
		*/
		buffer.push(msg.data);
        readFromBuffer();
	} 
	
	function setupSourceBuffer(videoId)
	{


		window.MediaSource = window.MediaSource || window.WebKitMediaSource;
		if (!window.MediaSource) {
		  console.log('MediaSource API is not available');
		}

		mediaSource = new window.MediaSource();
	
		video = document.getElementById(videoId);
		video.autoplay = true;

		var h5spath = video.getAttribute('h5spath');
		

		/* var video = document.querySelector('h5sVideo'); */
		//alert(h5spath);
		video.src = window.URL.createObjectURL(mediaSource);
		video.play();

		mediaSource.addEventListener('sourceopen', mediaSourceOpen, false);
			
	}
	
	function mediaSourceOpen()
	{
		console.log("Add SourceBuffer");
		//var strCodec = 'video/mp4; codecs="avc1.420028"';
		//var strCodec = 'video/mp4; codecs="avc1.42E01E"';
		var strCodec = 'video/mp4; codecs="avc1.640029"';
		sourceBuffer = mediaSource.addSourceBuffer(strCodec);
		mediaSource.duration = Infinity;
		mediaSource.removeEventListener('sourceopen', mediaSourceOpen, false);
		sourceBuffer.addEventListener('updateend', readFromBuffer, false);		
	}
	
	function setupWebSocket()
	{
		video = document.getElementById(videoId);
		video.autoplay = true;
		
		var h5spath = video.getAttribute('h5spath');
		var token = video.getAttribute('token');
		h5spath = h5spath + "?token=" + token;
		console.log(h5spath);
		
		wsSocket = H5SWebSocketClient(h5spath);
		wsSocket.binaryType = 'arraybuffer';
		wsSocket.onmessage = onWebSocketData;
		wsSocket.onopen = function()
		{
			checkSourceBufferId = setInterval(CheckSourceBuffer, 3000);
			keepaliveTimerId = setInterval(keepaliveTimer, 1000);
		}
		
		wsSocket.onclose = function () {
			CleanupWebSocket();
			CleanupSourceBuffer();
			bNeedReconnect = true;
		}
	}
	
	
	function CleanupSourceBuffer()
	{
		console.log('Cleanup Source Buffer');
        sourceBuffer.removeEventListener('updateend', readFromBuffer, false);
		sourceBuffer.abort();

		if (document.documentMode || /Edge/.test(navigator.userAgent)) 
		{
			console.log('IE or EDGE!');
		}else
		{
			mediaSource.removeSourceBuffer(sourceBuffer);
		}
		//Clear the video source
		video.src = '';
		sourceBuffer = null;
		mediaSource = null;
		buffer = [];
		
	}
	
	function CleanupWebSocket()
	{
		clearInterval(keepaliveTimerId);
		clearInterval(checkSourceBufferId);
		emptyBuffCnt = 0;
		lastBuffTime = 0;
		buffTimeSameCnt = 0;
	}
	
	
	function CheckSourceBuffer()
	{
		console.log("CheckSourceBuffer", $(window).height(), $(document).height(), $(window).width(), $(document).width());
		if (sourceBuffer.buffered.length <= 0)
		{
			emptyBuffCnt ++;
			if (emptyBuffCnt > 8)
			{
				console.log("CheckSourceBuffer Close 1");
				wsSocket.close();
				return;
			}
		}else
		{
			emptyBuffCnt = 0;
			var buffStartTime = sourceBuffer.buffered.start(0);
			var buffEndTime = sourceBuffer.buffered.end(0);
			
			var buffDiff = buffEndTime - video.currentTime;
			if (buffDiff > 5 || buffDiff < 0)
			{
				console.log("CheckSourceBuffer Close 2");
				wsSocket.close();
				return;				
			}
			
			if ( buffEndTime == lastBuffTime)
			{
				buffTimeSameCnt ++;
				if (buffTimeSameCnt > 3)
				{
					console.log("CheckSourceBuffer Close 3");
					wsSocket.close();
					return;
				}
			}else
			{
				buffTimeSameCnt = 0;
			}
			
			lastBuffTime = buffEndTime;
			
		}
	}
	
	setupSourceBuffer(videoId);
	setupWebSocket();
	
}


