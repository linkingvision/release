export LD_LIBRARY_PATH=`pwd`/lib/:$LD_LIBRARY_PATH

./h5ss "rtsp://192.168.0.167:554/Streaming/Channels/101?transportmode=unicast&profile=Profile_1" admin admin

