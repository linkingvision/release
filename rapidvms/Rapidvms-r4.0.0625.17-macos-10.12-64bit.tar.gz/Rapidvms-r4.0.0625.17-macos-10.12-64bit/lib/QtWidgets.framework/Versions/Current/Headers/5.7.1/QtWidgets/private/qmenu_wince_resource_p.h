/****************************************************************************
**
** Copyright (C) 2016 The Qt Company Ltd.
** Contact: https://www.qt.io/licensing/
**
** This file is part of the QtWidgets module of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** Commercial License Usage
** Licensees holding valid commercial Qt licenses may use this file in
** accordance with the commercial license agreement provided with the
** Software or, alternatively, in accordance with the terms contained in
** a written agreement between you and The Qt Company. For licensing terms
** and conditions see https://www.qt.io/terms-conditions. For further
** information use the contact form at https://www.qt.io/contact-us.
**
** GNU Lesser General Public License Usage
** Alternatively, this file may be used under the terms of the GNU Lesser
** General Public License version 3 as published by the Free Software
** Foundation and appearing in the file LICENSE.LGPL3 included in the
** packaging of this file. Please review the following information to
** ensure the GNU Lesser General Public License version 3 requirements
** will be met: https://www.gnu.org/licenses/lgpl-3.0.html.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU
** General Public License version 2.0 or (at your option) the GNU General
** Public license version 3 or any later version approved by the KDE Free
** Qt Foundation. The licenses are as published by the Free Software
** Foundation and appearing in the file LICENSE.GPL2 and LICENSE.GPL3
** included in the packaging of this file. Please review the following
** information to ensure the GNU General Public License requirements will
** be met: https://www.gnu.org/licenses/gpl-2.0.html and
** https://www.gnu.org/licenses/gpl-3.0.html.
**
** $QT_END_LICENSE$
**
****************************************************************************/

//
//  W A R N I N G
//  -------------
//
// This file is not part of the Qt API.  It exists purely as an
// implementation detail.  This header file may change from version to
// version without notice, or even be removed.
//
// We mean it.
//


#define IDR_MAIN_MENU       102
#define IDR_MAIN_MENU2      103
#define IDR_MAIN_MENU3      104
#define IDS_EXIT            105
#define IDS_MENU            106
#define IDS_LEFTMENU        107
#define IDM_ABOUT           108
#define IDM_VIEW            109
#define IDM_ITEM1           108
#define IDM_ITEM2           109
#define IDM_ITEM3           110
#define IDM_ITEM4           111
#define IDM_ITEM5           112
#define IDM_ITEM6           113
#define IDM_ITEM7           114
#define IDM_ITEM8           115
#define IDS_MENU1           116
#define IDS_MENU2           117
#define IDS_MENU3           118
#define IDS_MENU4           119
#define IDS_MENU5           120
#define IDS_MENU6           121
#define IDS_MENU7           122
#define IDS_MENU8           123
#define IDR_MAIN_MENU4      124
#define IDR_MAIN_MENU5      125
#define IDM_EXIT            40000
#define IDM_MENU            40001
#define IDM_LEFTMENU        40002
#define IDM_MENU1           40003
#define IDM_MENU2           40004
#define IDM_MENU3           40005
#define IDM_MENU4           40006
#define IDM_MENU5           40007
#define IDM_MENU6           40008
#define IDM_MENU7           40009
#define IDM_MENU8           40010

