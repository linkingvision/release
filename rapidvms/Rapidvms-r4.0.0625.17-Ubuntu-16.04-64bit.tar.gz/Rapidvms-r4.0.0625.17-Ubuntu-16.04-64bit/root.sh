sudo su -p

